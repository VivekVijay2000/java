import java.awt.*;
import java.util.*;
public class Hmap
{

	public static void main(String args[])
	{
		Map<String,Integer> map=new HashMap<>();
		map.put("orange",10);
		map.put("apple",20);
		map.put("grapes",30);
		System.out.println("orginal Map:");
		for(Map.Entry<String,Integer> e : map.entrySet())
		System.out.println(e.getKey()+ " " + e.getValue());
		map.remove("apple");
		
		System.out.println("Map after removing:");
		for(Map.Entry<String,Integer> e : map.entrySet())
		System.out.println(e.getKey()+ " " + e.getValue());
		map.replace("grapes",400);
		
		
		System.out.println("Map after replace:");
		for(Map.Entry<String,Integer> e : map.entrySet())
		System.out.println(e.getKey()+ " " + e.getValue());
	}
}
		
		
		
		

