import  java.util.*;
public class ArraylistExp
{
	public static void main(String args[])
	{
		ArrayList<String> list=new ArrayList<String>();
		list.add("help");
		list.add("welcome");
		list.add("do");
		list.add("sleep");
		list.add("beep");
		System.out.println(list);
		System.out.println("returning element:"+list.get(1));
		list.set(1,"newly inserted");
		System.out.println("List after insertion of:newly inserted");
		
		for(String word:list)
		System.out.println(word);
		
		//for sorting
		Collections.sort(list);
		System.out.println("sorted list:");
		for(String word:list)
		System.out.println(word);
	}
}

		
		
