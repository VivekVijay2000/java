import java.util.*;
class FibThread implements Runnable
{
	public void run()
	{
		int a,b,c;
		a=0;
		b=1;
		c=0;
		System.out.println("Fibthread:"+a);
		System.out.println("Fibthread:"+b);
	try
	{
		for(int h=1;h<=7;h++)
		{
			c=a+b;
			System.out.println("FibThread:"+c);
			a=b;
			b=c;
			Thread.sleep(1000);
		}
	}
		catch(InterruptedException e)
		{
			System.out.println("Child intterupted");
		}
	}
}
		
class EvenRangeThread implements Runnable
{
	public void run()
	{
	try
	{
	 	int a=2;int b=10;int k;
	 	for(k=a;k<=b;k+=2)
	 	{
	 		System.out.println("Evenrangethread:"+k);
	 		Thread.sleep(500);
	 	}
	 }
	 
	 catch(InterruptedException e)
	 {
	 	System.out.println("child interuppted");
	 }
	 }
}
public class Fib
{
	public static void main(String args[] ) {
	FibThread ft = new FibThread();
	EvenRangeThread er = new EvenRangeThread();
	Thread t1 = new Thread(ft);
	Thread t2 = new Thread(er);
	t1.start();
	t2.start();
}
}

	 	
	 
	 
