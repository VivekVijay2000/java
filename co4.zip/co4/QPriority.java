import java.util.PriorityQueue;
import java.util.Queue;
public class QPriority
{
	public static void main(String args[])
	{
		Queue<String> pq=new PriorityQueue<>();
		pq.add("welcome");
		pq.add("have");
		pq.add("your");
		pq.add("eat");
		System.out.println("Orginal Queue:" + pq);
		pq.remove("your");
		System.out.println("After Remove" + pq);
		System.out.println("poll method :" + pq.poll());
		System.out.println("Final Queue" + pq);
		System.out.println(pq.peek());
	}
}
		
		
		
