import java.util.*;
public class sort {

   public static void main(String args[]) 
{
      int a;
      String n;
      Scanner s = new Scanner(System.in);
      System.out.println("ENTER THE LIMIT:");
      a=s.nextInt();
      String c[]=new String[a];
      System.out.println("Enter a strings\n");
      for(int i=0;i<a;i++)
      {
      		
      		 c[i]=s.next();
      }
      Arrays.sort(c);
      System.out.println("SORTED STRING\n");
       for(int i=0;i<a;i++)
      {
      		System.out.println(i+1 + ":" + c[i]);
      }
      
    }
   
}


