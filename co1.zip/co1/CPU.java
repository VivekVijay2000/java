import java.util.*;
class cpu

{
	int price;
public class Processor
{
void processor()
{

	int core;
	String manufacturer;
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the number of core:");
	core=s.nextInt();
	System.out.println("Enter the manufacturer:");
	manufacturer=s.next();
	System.out.println("\nCORE:"+core+"\nMANUFACTURER"+manufacturer);
}
}
static class RAM
{
void ram()
{
	int memory;
	String manufacturer;
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the number of memory:");
	memory=s.nextInt();
	System.out.println("Enter the manufacturer:");
	manufacturer=s.next();
	System.out.println("\nMEMORY:"+memory+"\nMANUFACTURER"+manufacturer);
}
}
}
public class CPU
{
	public static void main(String[] args)
	{
	  cpu c=new cpu();
	  cpu.Processor pro=c.new Processor();
	  pro.processor();
	  cpu.RAM r=new cpu.RAM();
	  r.ram();
	 }
}


	
	
