
import java.util.*;

class product
{
	int pcode;
	String pname;
	int price;
	
void getdata()
{
   
    Scanner s=new Scanner(System.in);
    System.out.println("enter the pcode");
    pcode=s.nextInt();
     System.out.println("enter the pname");
    pname=s.next();
     System.out.println("enter the price");
    price=s.nextInt();
}

void display()
{
	System.out.println(pcode+" "+pname+" "+price);
}
}
class product1
{
public static void main(String[] args)
   {
	product p1=new product();
	product p2=new product();
	product p3=new product();
	p1.getdata();
	p2.getdata();
	p3.getdata();
   
   if((p1.price<p2.price)&&(p1.price<p3.price))
   {
   	System.out.println(p1.price+"is lowest");
   	p1.display();
   }
   else if((p2.price<p1.price)&&(p2.price<p3.price))
   {
       System.out.println(p2.price+"is lowest");
       p2.display();
    }
    else
    {
       System.out.println(p3.price+"is lowest");
       p3.display();
    }
    }
}
     
	
	
		
