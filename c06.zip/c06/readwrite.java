import java.io.*;
import java.util.*;
class readwrite{
	public static void main(String[] args) throws IOException{
	
	
	try{
	
	//writing into file
	 FileWriter fw=new FileWriter("input.txt");    
           fw.write("FISAT COLLEGE OF ENGINEERING\nWILFRED\nVISHNU\nMIVIN\nVYSHNAV\nVIVEK");    
           fw.close(); 
           
           
           
		//reads file
		File f1 =new File("input.txt");
		Scanner d =new Scanner(f1);
      
		while (d.hasNextLine())
			{
			String fileData=d.nextLine();
			// displayin
			System.out.println(fileData);
			}
			d.close();	
		}
		catch (FileNotFoundException e){
			System.out.println("Unexpected error occured!");
			e.printStackTrace();
			}
		}
	}

